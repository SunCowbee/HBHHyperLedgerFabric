docker rm `docker ps -aq` -fv
